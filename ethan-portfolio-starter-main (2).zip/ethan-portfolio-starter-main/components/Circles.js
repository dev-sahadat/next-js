const Circles = () => {
  return <div>Circles</div>;
};

export default Circles;
