const TopLeftImg = () => {
  return <div>Top Left Image</div>;
};

export default TopLeftImg;
