const Avatar = () => {
  return <div>Avatar</div>;
};

export default Avatar;
