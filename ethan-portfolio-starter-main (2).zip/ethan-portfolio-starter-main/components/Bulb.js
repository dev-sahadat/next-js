const Bulb = () => {
  return <div>Bulb</div>;
};

export default Bulb;
