const Transition = () => {
  return (
    <>
      <div>Transition</div>
    </>
  );
};

export default Transition;
