const ParticlesContainer = () => {
  return <div>Particles Container</div>;
};

export default ParticlesContainer;
