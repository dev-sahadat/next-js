const Layout = () => {
  return <div>Layout</div>;
};

export default Layout;
