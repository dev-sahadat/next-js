const Work = () => {
  return <div>Work</div>;
};

export default Work;
